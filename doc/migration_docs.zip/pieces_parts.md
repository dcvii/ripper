# pieces and parts

## the setup
- poetry
- direnv
- token.sh

## The getters
- get_grants
- get_schema
- get_token


## The putters
The job of the putters is to push data out to s3 and local flat sql files. These will be the import scripts and the export scripts.