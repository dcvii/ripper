# runner.py

### abstract
This code will execute the scripts created by get_grants and others 