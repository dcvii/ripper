# sql query types

input | output | type
------|--------|------
single multiline| dontcare | A
single multiline| multiline results | B
multiple single line | single row results | C
