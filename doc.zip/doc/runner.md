# sql_runner.py

### abstract
This code will execute the scripts created by get_grants and others 

current runner module procs


- vert_conn(cfg)
- chunkify(fname)
- run\_multi_sql(cset,config)
- run\_single\_file_sql(config)
- run\_single\_file\_commit_sql(config)
- run\_migration\_table(config)


### sql_runner config



