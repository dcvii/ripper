#features


### major features
Generates scripts for import & export​

Handles large numbers of SQL statements​

Error handling​

Configurable​

Migration Schema​

Migration logging


---

### other features

- runs schema by schema