# migrator installation instructions

### software requirements

- python >= v3.9 (https://www.python.org/downloads/release/python-390/)
- poetry (https://python-poetry.org/docs/)
- direnv (https://direnv.net/)
 


