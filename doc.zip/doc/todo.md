# development to do list


### documentation
- manual process for getting sts token 


### core
- chunking for sql_runner when queries > 1000 (inside, outside loop)
- doc
- 

### fixes
- fix bad grant syntax from get_grants.py